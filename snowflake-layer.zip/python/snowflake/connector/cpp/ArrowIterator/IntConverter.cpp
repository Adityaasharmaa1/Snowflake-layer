//
// Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
//

#include "IntConverter.hpp"

namespace sf
{
/** this file is here for future use and if this is useless at the end, it will
 * be removed */
}  // namespace sf
